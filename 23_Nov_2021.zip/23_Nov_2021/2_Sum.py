x=55
y=55
z=x+y

print("sum:",z)

print("5+7=", z)

print(x,"+",y,"=",z)

print("sum of",x,"and",y,"is",z)
