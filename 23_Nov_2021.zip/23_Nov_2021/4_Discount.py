amt =4000
disc= 20

bill = amt - (amt * (disc/100))
print("Bill is:",bill)