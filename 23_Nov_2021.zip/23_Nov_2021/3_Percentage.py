s1=90
s2=95
s3=99

sum = s1+s2+s3
perc = (sum/300) *100

print("Percentage :",perc,"%")