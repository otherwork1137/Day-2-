print("hello all !!!! @@@@")
print('Welcome.....')

print("one",end="$")
print("two")
print("three")

print("First\tSecond\tThird")

print("One\nTwo\nThree")

print('''First
Second
        Third''')